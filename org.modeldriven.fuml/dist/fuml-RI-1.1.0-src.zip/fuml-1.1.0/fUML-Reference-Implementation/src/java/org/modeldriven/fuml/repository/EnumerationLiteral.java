package org.modeldriven.fuml.repository;

public interface EnumerationLiteral extends InstanceSpecification {
    public Enumeration getEnumeration();
}
