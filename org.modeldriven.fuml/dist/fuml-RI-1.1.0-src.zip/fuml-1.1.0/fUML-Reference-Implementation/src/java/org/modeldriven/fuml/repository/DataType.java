package org.modeldriven.fuml.repository;


public interface DataType extends Classifier {

	public fUML.Syntax.Classes.Kernel.DataType getDelegate();         
    
} // DataType
