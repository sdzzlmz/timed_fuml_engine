package org.modeldriven.fuml.repository;



public interface Stereotype extends Class_ {


} // Stereotype
