package org.modeldriven.fuml.repository.ext;



public class ExtensionEnd extends fUML.Syntax.Classes.Kernel.Property {


} // ExtensionEnd
