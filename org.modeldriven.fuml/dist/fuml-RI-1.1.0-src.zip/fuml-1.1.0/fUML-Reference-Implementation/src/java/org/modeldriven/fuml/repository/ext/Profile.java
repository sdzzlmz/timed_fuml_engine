package org.modeldriven.fuml.repository.ext;



public class Profile extends fUML.Syntax.Classes.Kernel.Package {


} // Profile
