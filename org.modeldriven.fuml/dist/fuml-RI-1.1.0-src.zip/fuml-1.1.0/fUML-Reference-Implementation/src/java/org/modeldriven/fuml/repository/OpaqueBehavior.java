package org.modeldriven.fuml.repository;


public interface OpaqueBehavior extends NamedElement {
    public String getLanguage();
    public String getBody();
}
