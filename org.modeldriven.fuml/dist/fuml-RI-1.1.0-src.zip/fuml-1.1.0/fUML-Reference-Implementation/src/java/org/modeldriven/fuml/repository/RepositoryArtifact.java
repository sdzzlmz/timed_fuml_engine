package org.modeldriven.fuml.repository;

public interface RepositoryArtifact {
	public String getURN();
	public String getNamespaceURI();
}
