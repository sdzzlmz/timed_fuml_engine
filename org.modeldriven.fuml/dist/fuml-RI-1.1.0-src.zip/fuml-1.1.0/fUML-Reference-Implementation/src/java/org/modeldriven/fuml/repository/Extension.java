package org.modeldriven.fuml.repository;


public interface Extension extends Association {

	public org.modeldriven.fuml.repository.ext.Extension getDelegate(); 
	        
    
} // Extension
