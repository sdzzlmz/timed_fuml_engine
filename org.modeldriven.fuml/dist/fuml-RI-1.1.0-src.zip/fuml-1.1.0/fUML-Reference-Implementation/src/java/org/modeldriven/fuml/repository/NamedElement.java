package org.modeldriven.fuml.repository;



public interface NamedElement extends Element {


    public String getQualifiedName();
    
    public String getName();

} // NamedElement
